const users= require('./users');
const videofile= require('./videofile');



module.exports={
    users,
    videofile
}
