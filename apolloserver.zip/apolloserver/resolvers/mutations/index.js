const addUser= require('./addUser')
const addVideo= require('./addVideo')

module.exports = {
   addUser,
   addVideo
};
