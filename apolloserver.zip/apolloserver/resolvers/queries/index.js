const user= require('./users')
const video = require('./videos')

module.exports = {
    user,
    video
};
