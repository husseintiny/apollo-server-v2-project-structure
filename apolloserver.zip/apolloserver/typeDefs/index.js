const user= require('./types/user');
const video= require('./types/video');

const queries= require('./queries');

module.exports=[
    user,
    queries,
    video
]
